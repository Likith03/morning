import React from "react";
import { Component } from "react";

class AppComp extends Component{
    powerInput = React.createRef();
    state = {
        power : 0
    }
    /*
    constructor(){
        super();
        this.increasePower = this.increasePower.bind(this);
    }
    */
   /*
    increasePower = (evt) => {
        this.setState({
           // power : this.state.power + 1
           power : evt.target.value
        })
    }
    
   setPowerTo10(val){
    this.setState({
        power : val
    })
   }*/
  setPowerFromInput = ()=>{
    this.setState({
        power : this.powerInput.current.value
    })
  }
    render(){
        return <div>
                  <h1>Welcome to your life</h1>
                  <h2>Power is { this.state.power }</h2>
                 {/* <button onClick={this.increasePower.bind(this)}>Increase Power</button>
                  <button onClick={this.increasePower}>Increase Power</button> 
                  <input onInput={ this.increasePower } type="range" /> 
                  <button onClick={ ()=> this.setPowerTo10(10) }>Increase Power to 10</button> */}
                  <input ref={this.powerInput} type="number" />
                  <button onClick={this.setPowerFromInput}>Set Power</button>         
             </div>
    }
}
export { AppComp };