import React, { Component } from "react";
import { HeroComp } from "./hero.component";

class AppComp extends Component{
    show = true
    state = {
        justiceleague : {
            title: "Justice League",
            heroes : ['Superman', 'Batman', 'Aquaman']
        },
        avengers : {
            title: "Avengers",
            heroes : ['Ironman', 'Hulk']
        },
        indichero : {
            title : "Indichero",
            heroes : ['ChotaBheem','Shakthiman']
        }
    }
    toggleShowhide = ()=>{
        this.setState({
            show : !this.state.show
        })
    }
 /*
    render(){
        if(this.state.show){
        return <div>
                  <h1>Iterations / Conditions </h1>
                  {
                      this.state.show ?
                      <div>
                           <button onClick={ this.toggleShowhide}>Show/Hide</button> 
                           <HeroComp heroeslist={ this.state.justiceleague.heroes } title={ this.state.justiceleague.title }/>
                           <HeroComp heroeslist={ this.state.avengers.heroes } title={ this.state.avengers.title }/>
                            <HeroComp heroeslist={ this.state.indichero.heroes } title={ this.state.indichero.title }/>
                      </div> :
                     <button onClick={ this.toggleShowhide}>Show/Hide</button> 
                  }
                   
                  
             </div>
    }
    */
    render(){
        return <div>
                  <h1>Iterations / Conditions </h1>
                  <button onClick={ this.toggleShowhide}>Show/Hide</button> 
                  {
                      this.state.show &&
                      <div>
                           <HeroComp heroeslist={ this.state.justiceleague.heroes } title={ this.state.justiceleague.title }/>
                           <HeroComp heroeslist={ this.state.avengers.heroes } title={ this.state.avengers.title }/>
                            <HeroComp heroeslist={ this.state.indichero.heroes } title={ this.state.indichero.title }/>
                      </div> 
                  }
                   
                  
             </div>
    }
}


export { AppComp };