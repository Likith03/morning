import React, { Component } from "react";
import { ChildComp } from "./child.component";

class AppComp extends Component{
    state ={
        power : 0,
        message : 'default message'
    }
    increasePower = ()=>{
        this.setState({
            power : this.state.power + 1
        })
    }
    decreasePower = ()=>{
        this.setState({
            power : this.state.power - 1
        })
    }
    setMessage = (nmessage) => {
        this.setState({
            message : nmessage
        })
    }
    render(){
        return <div>
            <h1>Communication</h1>
            <h2>Message is {this.state.message}</h2>
            <button onClick={ this.increasePower}>Increase Power</button>
            <button onClick={ this.decreasePower}>Decrease Power</button>
            <ChildComp messageHandler={this.setMessage} pow={ this.state.power } />
        </div>
    } 
}
export { AppComp };