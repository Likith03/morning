import React,{ Component } from "react";

class ChildComp extends Component{
    ipRef = React.createRef();
    render(){
        return <div style={ { border : "2px solid blue", padding : "10px", margin : "10px"}}>
                  <h2>Child Component</h2>
                  <h3>Power set from parent is : { this.props.pow }</h3>
                  <hr/>
                  <input ref={ this.ipRef } type="text" />
                  <button onClick={ ()=> this.props.messageHandler( this.ipRef.current.value )}> Send Message</button>
               </div>
    }
}
export { ChildComp };