import React, { Component } from "react";
// import "./comp.css";

class AppComp extends Component{
 state = {}
 compStyle = { backgroundColor :"crimson", color :"cornsilk", padding :"10px", textAlign :"justify" };
    render(){
        return <div>
             <h1> Styles </h1>
        <div style={ { backgroundColor :"lightgreen", color :"cornsilk", padding :"10px", textAlign :"justify" } }>
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Harum quidem neque deserunt adipisci autem sequi dolor minima dolore magnam molestias distinctio tempora quod excepturi, aliquam id quam explicabo rem consectetur.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque libero distinctio, possimus perferendis soluta totam ipsum cum provident consequuntur repellat aspernatur quae quisquam beatae! Sit unde nisi facere qui perspiciatis!
            Lorem ipsum dolor sit amet consectetur, adipisicing elit. Id itaque blanditiis at, alias maiores repudiandae ullam ut illum inventore, ipsa ex assumenda temporibus labore incidunt, debitis enim iure fugiat aperiam!
        </div>
        <br></br>
        <div style={ this.compStyle}>
        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Harum quidem neque deserunt adipisci autem sequi dolor minima dolore magnam molestias distinctio tempora quod excepturi, aliquam id quam explicabo rem consectetur.
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque libero distinctio, possimus perferendis soluta totam ipsum cum provident consequuntur repellat aspernatur quae quisquam beatae! Sit unde nisi facere qui perspiciatis!
        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Id itaque blanditiis at, alias maiores repudiandae ullam ut illum inventore, ipsa ex assumenda temporibus labore incidunt, debitis enim iure fugiat aperiam!
    </div>
    <br></br>
    <div className="box">
    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Harum quidem neque deserunt adipisci autem sequi dolor minima dolore magnam molestias distinctio tempora quod excepturi, aliquam id quam explicabo rem consectetur.
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque libero distinctio, possimus perferendis soluta totam ipsum cum provident consequuntur repellat aspernatur quae quisquam beatae! Sit unde nisi facere qui perspiciatis!
    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Id itaque blanditiis at, alias maiores repudiandae ullam ut illum inventore, ipsa ex assumenda temporibus labore incidunt, debitis enim iure fugiat aperiam!
</div>
 </div>            
    }
}


export { AppComp };