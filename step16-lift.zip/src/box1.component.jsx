import { Component } from "react";
class Box1Comp extends Component{
render(){
return <div style={ { border : "2px solid grey", padding : "10px", margin : "10px"} }>
                <h2>Box 1 Component</h2>
       </div>
}
}
export default Box1Comp;