import { Component } from "react";
import FirstComp from "./first.component";
import SecondComp from "./second.component";
class App extends Component{
    render(){
        return <div  style={ { border : "2px solid grey", padding : "10px", margin : "10px"} }>
                    <h1>React Lifting State</h1>
                    <FirstComp></FirstComp>
                    <SecondComp></SecondComp>
               </div>
    }
}
export default App;