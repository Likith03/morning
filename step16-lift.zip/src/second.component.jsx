import { Component } from "react";
import Box3Comp from "./box3.component";
import Box4Comp from "./box4.component";
class SecondComp extends Component{
render(){
return <div  style={ { border : "2px solid grey", padding : "10px", margin : "10px"} }>
                <h2>First Component</h2>
                <Box3Comp/>
                <Box4Comp/>
       </div>
}
}
export default SecondComp;