import { Component } from "react";
import Box1Comp from "./box1.component";
import Box2Comp from "./box2.component";
class FirstComp extends Component{
render(){
return <div  style={ { border : "2px solid grey", padding : "10px", margin : "10px"} }>
                <h2>First Component</h2>
                <Box1Comp/>
                <Box2Comp/>
       </div>
}
}
export default FirstComp;