import { Component } from "react";

class Childcomp extends Component{
    render(){
        return <div>
            <h2>Hello from Child Component</h2>
            { this.props.children }
        </div> 
    }
};
export{ Childcomp }