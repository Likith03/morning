import { Component } from "react";
import { Childcomp } from "./child";

class App extends Component{
    firstcompTitle = "First Component Title";
    secondcompTitle = "Second component Title";
    render(){
        return <div>
            <h1>Welcome to your Life</h1>
            <Childcomp>{ this.firstcompTitle}</Childcomp>
            <Childcomp>{ this.secondcompTitle}</Childcomp>
        </div>

        }
    }
export { App }