import React from "react";
import { createRoot} from "react-dom/client";
import Elm from "./elm";
/*
let template = "Welcome to your life";
let elm = React.createElement("h1", null,template);
*/
// JSX
// <h1>Welcome to your life</h1>
/*
let txt1 = "List Item 1"
let txt2 = "List Item 2"
let elm = <ul>
            <li>txt1</li>
            <li>txt2</li>
          </ul>
*/
/*
let txt1 = "List Item 1"
let txt2 = "List Item 2"
let elm = <ul>
            <li>{ txt1 }</li>
            <li>{ txt2 }</li>
          </ul>
*/
/*
let Elm = function(){
  let txt1 = "List Item 1"
  let txt2 = "List Item 2"
return <ul>
         <li>{ txt1 }</li>
         <li>{ txt2 }</li>
      </ul>
}
*/

class Elm extends Component{
    render(){
    let txt1 = "List Item 1"
    let txt2 = "List Item 2"
    return <ul>
        <li>{ txt1 }</li>
        <li>{ txt2 }</li>
    </ul>
}
}

createRoot(document.getElementById("root"))
.render(<Elm/>);
// .render(Elm());