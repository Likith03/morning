import React from "react";
import { Component } from "react";

class AppComp extends Component{
    powerInput = React.createRef();
    state = {
        power : 0
    }
 
  increasePower = ()=>{
    this.setState(
        function(currentState, currentProps){
            return{
                power : currentState.power + currentProps.val
            }
        },
        function(){
            if(this.state.power === 5){
                alert("power is now 5")
            }
    });
  }
  decreasePower = ()=>{
    this.setState({
         power : this.state.power - 1
     })
  }
    render(){
        return <div>
                  <h1>Welcome to your life</h1>
                  <h2>Power is { this.state.power }</h2>
                  <button onClick={this.increasePower}>Increase Power</button>    
                  <button onClick={this.decreasePower}>Decrease Power</button>      
             </div>
    }
}
export { AppComp };