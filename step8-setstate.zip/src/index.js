import { createRoot } from "react-dom/client";
import { AppComp } from "./app.component";

createRoot(document.getElementById("root")).render(<AppComp val={10}/>)