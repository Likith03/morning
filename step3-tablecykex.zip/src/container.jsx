import { Component } from "react";
import { Products } from "./product";

class Container extends Component{
    render(){
        return <div class="album py-5 bg-light">
                  <div class="container">
                      <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
                        <Products/>
                        <Products/>
                        <Products/>
                        <Products/>
                        <Products/>
                        <Products/>
                        <Products/>
                        <Products/>
                        <Products/>

                      </div>
                  </div>
             </div>
    }
}

export { Container };