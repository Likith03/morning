import { Component } from "react";
import { Container } from "./container";
import { Footer } from "./footer";
import { HeaderComp } from "./header";
import { HeroComp } from "./hero";

class App extends Component{
    render(){
        return <div>
                  <HeaderComp/>
                  <main>
                    <HeroComp/>
                    <Container/>
                  </main>
                <Footer/>
               </div>

        }
    }
export { App }