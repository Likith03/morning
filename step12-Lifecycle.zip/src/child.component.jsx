import React, { Component } from "react";
 
class ChildComp extends Component{
    ipRef = React.createRef();
    state = {};
    constructor(){
        super();
        console.log("ChildComp's constructor was called")
    }
    componentDidMount(){
        console.log("ChildComp's componentDidMount was called")
    }
    static getDerivedStateFromProps(){
        console.log("ChildComp's getDerivedStateFromProps was called")
        return true
    }
    shouldComponentUpdate(){
        console.log("ChildComp's shouldComponentUpdate was called")
        return true
    }
    getSnapshotBeforeUpdate(){
        console.log("ChildComp's getSnapshotBeforeUpdate was called")
        return {}
    }
    componentDidUpdate(){
        console.log("ChildComp's componentDidUpdate was called")
    }
    componentWillUnmount(){
        console.log("ChildComp's componentWillUnmount was called")
    }
    render(){
        console.log("ChildComp's render was called")
        return <div style={ { border : "2px solid red", padding :"10px", margin : "10px" }}>
                <h2> Child Component </h2>
                <h3>Power sent from parent is : { this.props.pow }</h3>
               </div>
        }
}
 
export default ChildComp;