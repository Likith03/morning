import React, { Component } from "react";
import ChildComp from "./child.component";
class AppComp extends Component{
    state = {
        power : 0,
        show : true
    }
    increasePower = ()=>{
        this.setState({
            power : this.state.power + 1
        })
    }
    decreasePower = ()=>{
        this.setState({
            power : this.state.power - 1
        })
    }
    render(){
        return <div>
                <h1> LifeCycle Events </h1>
                <button onClick={()=> this.setState({ show : !this.state.show })}>Show / Hide | Child Component</button>
                <br />
                <br />
                <button onClick={ this.increasePower }>Increase Power</button>
                <button onClick={ this.decreasePower }>Decrease Power</button>
                { this.state.show && <ChildComp pow={ this.state.power }/>}
               </div>
        }
}
 
export {AppComp};